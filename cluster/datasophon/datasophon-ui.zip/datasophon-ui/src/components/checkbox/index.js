import ColorCheckbox from '@/components/checkbox/ColorCheckbox'
import ImgCheckbox from '@/components/checkbox/ImgCheckbox'

export {
  ColorCheckbox,
  ImgCheckbox
}
