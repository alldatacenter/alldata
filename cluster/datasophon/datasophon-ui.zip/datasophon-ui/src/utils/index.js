import baseUtils from './baseUtils'

global.utils = baseUtils