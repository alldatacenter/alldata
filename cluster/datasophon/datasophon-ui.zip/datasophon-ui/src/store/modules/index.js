/*
 * @Author: mjzhu
 * @describe: 
 * @Date: 2022-05-24 10:28:22
 * @LastEditTime: 2022-06-17 16:31:02
 * @FilePath: \ddh-ui\src\store\modules\index.js
 */
import account from './account'
import setting from './setting'
import steps from './steps/steps'

export default {account, setting, steps}